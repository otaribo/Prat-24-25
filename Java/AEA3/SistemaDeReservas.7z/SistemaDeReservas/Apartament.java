package Java.AEA3.SistemaDeReservas;

public class Apartament extends Allotjament {
    
}
