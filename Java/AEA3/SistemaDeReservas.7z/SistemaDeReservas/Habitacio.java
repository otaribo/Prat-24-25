package Java.AEA3.SistemaDeReservas;

public class Habitacio extends Allotjament {
    
}
